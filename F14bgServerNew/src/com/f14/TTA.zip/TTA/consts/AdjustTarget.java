package com.f14.TTA.consts;

/**
 * 调整目标
 * 
 * @author F14eagle
 *
 */
public enum AdjustTarget {
	/**
	 * 所有
	 */
	ALL, /**
			 * 最好的一个
			 */
	BEST
}
