package com.f14.TTA.component.card;

/**
 * 军事牌
 * 
 * @author F14eagle
 *
 */
public class MilitaryCard extends TTACard {

	@Override
	public MilitaryCard clone() {
		return (MilitaryCard) super.clone();
	}
}
